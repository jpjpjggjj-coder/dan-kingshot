DAN KingShot 熊罠攻略 v216 AI安定版
GitHub Pagesでは index.html と latest-data.json を同じ場所に置いてください。
